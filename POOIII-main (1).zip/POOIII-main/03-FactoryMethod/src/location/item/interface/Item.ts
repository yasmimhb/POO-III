export default interface Item{
    start(): void;
    getDescription(): void;
}